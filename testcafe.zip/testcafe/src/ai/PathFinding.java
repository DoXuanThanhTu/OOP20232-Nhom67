package ai;

import java.awt.Color;

import java.awt.Graphics2D;
import java.util.ArrayList;

import entity.Entity;
import main.GamePanel;

public class PathFinding {
	GamePanel gp;
	public Node[][] node;
	Graphics2D g2;
	public ArrayList<Node> openList = new ArrayList<Node>();
	public ArrayList<Node> pathList = new ArrayList<Node>();
	public Node startNode, goalNode, currentNode;
	public boolean goalReach = true;
	int step = 0;
	
	public PathFinding(GamePanel gp) {
		this.gp = gp;
		instalNodes();
		
	}
	
	public void instalNodes() {
		node = new Node[gp.colInDisplays][gp.rowInDisplays];
		
		int col = 0;
		int row = 0;
		
		while(col < gp.colInDisplays && row < gp.rowInDisplays) {
			node[col][row] = new Node (col, row);
			col++;
			
			if (col == gp.colInDisplays) {
				col = 0;
				row++;
			}
		}
	}
	public void resetNode() {
		int col = 0;
		int row = 0;
		while(col < gp.colInDisplays && row < gp.rowInDisplays) {
			node[col][row].opened = false;
			node[col][row].checked = false;
			node[col][row].soild = false;
			
			col++;
			if (col == gp.colInDisplays) {
				col = 0;
				row++;
			}
		}
		openList.clear();
		pathList.clear();
		goalReach = false;
		step = 0;
	}
	
	public void setNodes(int startCol, int startRow, int goalCol, int goalRow) {
		resetNode();
		
		startNode = node[startCol][startRow];
		currentNode = startNode;
		goalNode = node[goalCol][goalRow];
		openList.add(currentNode);
		
		for (int i = 0; i < gp.obj.size(); i++) {
			Entity x = gp.obj.get(i);
			for (int w = 0; w < x.hitBox[2] / gp.tileSizeWidth; w++) {
				for (int h = 0; h < x.hitBox[3]/ gp.tileSizeHeight; h++) {
					node[(x.screenX + x.hitBox[0])/gp.tileSizeWidth + w][(x.screenY+x.hitBox[1])/gp.tileSizeHeight + h].soild = true;
				}
			}
		}
	}

	public void getCost(Node node) {
		int xDistance = Math.abs(node.col - startNode.col);
		int yDistance = Math.abs(node.row - startNode.row);
		node.gCost = xDistance + yDistance;
		
		int xDistance2 = Math.abs(node.col - goalNode.col);
		int yDistance2 = Math.abs(node.row - goalNode.row);
		node.hCost = xDistance2 + yDistance2;
		
		node.fCost = node.gCost + node.hCost;
	}
	
	public boolean search() {
		while(goalReach == false ) {
			int col = currentNode.col;
			int row = currentNode.row;
			
			if (currentNode.soild == false) {
				currentNode.checked = true;
				openList.remove(currentNode);
				if(col - 1 > 0) {
					openNode(node[col-1][row]);
				}
				if (row - 1 > 0) {
					openNode(node[col][row-1]);
				}
				if (col < gp.colInDisplays - 1) {
					openNode(node[col+1][row]);
				}
				if (row < gp.rowInDisplays - 1) {
					openNode(node[col][row+1]);
				}
			}
			
			int bestNodeIndex = 0;
			int bestNodefCost = 999;
			
			for (int i = 0; i < openList.size(); i++) {
				if(openList.get(i).fCost < bestNodefCost) {
					bestNodeIndex = i;
					bestNodefCost = openList.get(i).fCost;
				}else if (openList.get(i).fCost == bestNodefCost) {
					if (openList.get(i).gCost < openList.get(bestNodeIndex).gCost) {
						bestNodeIndex = i;
					}
				}
			}
			if (openList.size() == 0) {
				break;
			}
			currentNode = openList.get(bestNodeIndex);
			if(currentNode == goalNode) {
				goalReach = true;
				trackThePath();
			}
		}
		return goalReach;
	}
	
	private void trackThePath() {
		Node current = goalNode;
		while(current != startNode) {
			pathList.add(current);
			current = current.parent;
		}
		
	}
	public void drawPath(Graphics2D g2) {
		for (Node x : pathList) {
			int col = x.col;
			int row = x.row;
			g2.setColor(new Color(0, 255, 0, 70));
			g2.fillRect(col * 32, row * 32, 32, 32);
		}
	}
	public void openNode(Node node) {
		if(node.opened == false && node.checked == false && node.soild == false) {
			node.opened = true;
			node.parent = currentNode;
			openList.add(node);
		}
	}
}
