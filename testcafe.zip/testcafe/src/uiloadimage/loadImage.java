package uiloadimage;

import java.awt.image.BufferedImage;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;

import javax.imageio.ImageIO;

import main.GamePanel;
import main.UI;

public class loadImage {
	public UI ui;
	GamePanel gp;
	public ArrayList<BufferedImage> listImg = new ArrayList<BufferedImage>();
	public loadImage(GamePanel gp) {
		// TODO Auto-generated constructor stub
		this.gp = gp;
		setUp("button_start");
	}
	public void setUp(String imageName) {
		try {
			InputStream is = getClass().getResourceAsStream("/ui/" + imageName + ".png");
			BufferedImage img = ImageIO.read(is);
//			ui.listImage.add(img);
			listImg.add(img);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			System.out.println("k setup dc ui Image");
		}
		
	}
}
