package main;

import static main.GamePanel.*;

import java.awt.Cursor;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;

import javax.imageio.ImageIO;

import entity.Customer;
import entity.Entity;
import main.GamePanel;

public class MouseInput implements MouseMotionListener, MouseListener{
	private static final long CLICK_COOLDOWN = 500;
	public BufferedImage selectMouse ;
	public MouseImage mi = new MouseImage();
	GamePanel gp;
	public int x,y;
	public boolean clickObj = false;
	public boolean clickChefTable = false;
	public boolean clickTable4Person = false;
	public boolean clickCus = false;
	public boolean inAScreen = false;
	public int objIndex = 9999, cusIndex = 9999;
	public String stri = " ";
	public  boolean selectObj;
	private boolean selectCus;
	private long previousClickTime = 0;
    public int previousCusIndex = 9999;
    public int previousObjIndex = 9999;
   
	MouseInput(GamePanel gp){
		this.gp = gp;
//		getMouseImage();
		gp.setFocusable(true);
		
	}

	@Override
	public void mouseDragged(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseMoved(MouseEvent e) {
        x = e.getX();
        y = e.getY();
        if(gp.obj != null) {
        	if (selectObj ) {
                gp.setCursor(mi.getCursor2());
            } else {
                gp.setCursor(mi.getCursor1());
            }

            stri = "X : " + e.getX() + " Y : " + e.getY() + "\nCol :" + e.getX() / gp.tileSizeWidth + " Row : " + e.getY() / gp.tileSizeHeight;
            for (int i = 0; i < gp.obj.size(); i++) {
                Entity obj = gp.obj.get(i);
                if (inAScreen && x < obj.screenX + obj.widthObject && x > obj.screenX && y < obj.screenY + obj.heightObject && y > obj.screenY) {
                    selectObj = true;
                    break;
                }else selectObj = false;
            }
        }
       
    }
	@Override
	public void mouseClicked(MouseEvent e) {
		long currentTime = System.currentTimeMillis();
        if (currentTime - previousClickTime < CLICK_COOLDOWN) {
            return; 
        }
        previousClickTime = currentTime;

	    x = e.getX();
	    y = e.getY();
	    if (x < gp.screenWidth && x > 0 && y < gp.screenHeight && y > 0) {
	        inAScreen = true;
	    }
	    
	    if (objIndex == 9999) {
	        clickChefTable = false;
	        clickTable4Person = false;
	    }
	    
	    
	    
	    for (int i = 0; i < gp.obj.size(); i++) {
	        Entity obj = gp.obj.get(i);
	        if (inAScreen && x < obj.screenX + obj.widthObject && x > obj.screenX && y < obj.screenY + obj.heightObject && y > obj.screenY) {
	            if (e.getButton() == MouseEvent.BUTTON1) {
	                clickObj = true;
	                gp.playSE(2);
	                objIndex = i;
	                previousObjIndex = objIndex;
	                if (gp.obj.get(i).name.equals("cheftable1")) clickChefTable = true;
	                if (gp.obj.get(i).name.equals("table4person")) clickTable4Person = true;
	                
	                break; 
	            } else if (e.getButton() == MouseEvent.BUTTON2) {
	                gp.obj.remove(i);
	                break;
	            }
	        }
	    }
	    
	    for (int i = 0; i < gp.customers.size(); i++) {
	        Customer cus = gp.customers.get(i);
	        if (inAScreen && x < cus.screenX + cus.customerWidth && x > cus.screenX && y < cus.screenY + cus.customerHeight && y > cus.screenY) {
	            if (e.getButton() == MouseEvent.BUTTON1) {
	                if (previousCusIndex == i) {
	                    clickCus = !clickCus;
	                    cusIndex = clickCus ? i : 9999;
	                } else {
	                    clickCus = true;
	                    gp.playSE(1);
	                    cusIndex = i;
	                }
	                previousCusIndex = i;

	                gp.gameState = clickCus ? selectTableState : playState;
	                System.out.println(cusIndex);
	                System.out.println("clickCus: " + clickCus);
	                
	                break; 
	            } else if (e.getButton() == MouseEvent.BUTTON2) {
	                gp.customers.remove(i);
	                selectObj = false;
	                break;
	            }
	        }
	    }
	    if(gp.gameState == selectTableState && previousCusIndex != 9999 && previousObjIndex != 9999) {
	    	if(clickObj && gp.obj.get(objIndex).name == "table4person" ) {
	    		gp.gameState = playState;
	    		clickTable4Person = true;
	    		clickObj = false;
	    		if(gp.obj.get(previousObjIndex).isService == 0) {
	    		gp.obj.get(previousObjIndex).service = gp.customers.get(previousCusIndex);
	    		gp.obj.get(previousObjIndex).isService = 1;
	    		}else System.out.println("dang phuc vu");
	    	}
	    }
	    
	}

	
	
	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
	}
	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
	public void startMenuState() {
		
	}
	
	public int checkObject(Entity entity, boolean isPlayer) {
		int index = 9999;
		
		for (int i = 0; i < gp.obj.size(); i++) {
			int entityLeftscreenX =  entity.locationHitBox[0];
			int entityTopscreenY =  entity.locationHitBox[1];
			Rectangle entityHitBox = new Rectangle(entityLeftscreenX, entityTopscreenY, entity.locationHitBox[2], entity.locationHitBox[3]);
			int objX = gp.obj.get(i).screenX;
			int objY = gp.obj.get(i).screenY;
			Rectangle hitBoxObject = new Rectangle(objX + gp.obj.get(i).hitBox[0],objY + gp.obj.get(i).hitBox[1], gp.obj.get(i).hitBox[2],gp.obj.get(i).hitBox[3]);
			
			switch(entity.direction) {
			case "up" :
				entityHitBox.y -= entity.speed;
				if(entityHitBox.intersects(hitBoxObject)) {
					if(gp.obj.get(i).collison == true) {
						entity.collisionOn = true;
						System.out.println("Up collsion" + gp.obj.get(i).name);
					}
					if(isPlayer == true) {
						index = i;
					}
					
				}
				break;
			case "down" :
				entityHitBox.y += entity.speed;
				if(entityHitBox.intersects(hitBoxObject)) {
					if(gp.obj.get(i).collison ==true) {
						entity.collisionOn = true;
						System.out.println("Down collsion" + gp.obj.get(i).name);
					}
					if(isPlayer == true) {
						index = i;
					}
				}
				break;
			case "left" :
				entityHitBox.x -= entity.speed;
				if(entityHitBox.intersects(hitBoxObject)) {
					if(gp.obj.get(i).collison ==true) {
						entity.collisionOn = true;
						System.out.println("Left collsion"  + gp.obj.get(i).name);
					}
					if(isPlayer == true) {
						index = i;
					}
				}
				break;
			case "right" :
				entityHitBox.x += entity.speed;
				if(entityHitBox.intersects(hitBoxObject)) {
					if(gp.obj.get(i).collison ==true) {
						entity.collisionOn = true;
						System.out.println("Right collsion" + gp.obj.get(i).name);
					}
					if(isPlayer == true) {
						index = i;
					}
				}
				break;
			}
		}
		return index;
	}
	private void getMouseImage() {
		try {
			InputStream is = getClass().getResourceAsStream("/mouse/select.png");
			selectMouse = ImageIO.read(is);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
