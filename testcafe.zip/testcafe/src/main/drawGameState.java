package main;

import static main.GamePanel.pauseState;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;

public class drawGameState {
	GamePanel gp;
	public Graphics2D g2;
	public drawGameState(GamePanel gp) {
		this.gp = gp;
	}
	
		public void drawVictoryState(Graphics2D g2) {
			if(gp.gameState == gp.victoryState) {
				gp.add(gp.button_nextDay);
			// TODO Auto-generated method stub
			int width = gp.gs.stageImg.get(3).getWidth();
			int height = gp.gs.stageImg.get(3).getHeight();
			g2.drawImage(gp.gs.stageImg.get(3), (gp.screenWidth - width) / 2, (gp.screenHeight - height) / 2,width , height, null);
			g2.setFont(new Font("Arial", Font.PLAIN, 24));
			g2.setColor(Color.GREEN);
			g2.drawString("$" + String.valueOf(gp.income), 570, 415);
			g2.drawString("$" + String.valueOf(gp.income - gp.targetIncome), 505, 462);
			g2.setColor(Color.orange);
			g2.drawString("$" + String.valueOf(gp.targetIncome), 572, 365);
			gp.stopMusic();
			
		
		
	
}
		}
}
