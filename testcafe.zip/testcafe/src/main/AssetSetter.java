package main;



import java.awt.Rectangle;
import java.util.Random;


import entity.Chef;
import entity.Customer;
import main.GamePanel;
import entity.Waiter;
import object.OBJ_ChefTableCook;
import object.OBJ_SodaMachine;
import object.OBJ_Table4Person;
import object.OBJ_WaterMachine;


public class AssetSetter {
	GamePanel gp;
	public AssetSetter(GamePanel gp) {
		this.gp = gp;
	}
	
	public void loadObject() {
		gp.obj.add(new OBJ_SodaMachine("soda vending machine", gp));
		gp.obj.get(0).screenX = gp.tileSizeWidth * 14;
		gp.obj.get(0).screenY = gp.tileSizeWidth * 1;
		gp.obj.getLast().placeCome = new Rectangle(gp.obj.getLast().screenX , gp.obj.getLast().screenY + gp.obj.getLast().hitBox[3] + gp.tileSizeHeight * 2, gp.tileSizeWidth + 16, gp.tileSizeHeight + 16);
		gp.obj.add(new OBJ_WaterMachine("water vending machine", gp));
		gp.obj.get(1).screenX = gp.tileSizeWidth * 17;
		gp.obj.get(1).screenY = gp.tileSizeWidth * 1;
		gp.obj.getLast().placeCome = new Rectangle(gp.obj.getLast().screenX , gp.obj.getLast().screenY + gp.obj.getLast().hitBox[3]  + gp.tileSizeHeight * 2, gp.tileSizeWidth + 16, gp.tileSizeHeight + 16);
		gp.obj.add(new OBJ_ChefTableCook("cheftable1", gp));
		gp.obj.get(2).screenX = gp.tileSizeWidth * 20;
		gp.obj.get(2).screenY = gp.tileSizeWidth * 1;
		gp.obj.getLast().placeCome = new Rectangle(gp.obj.getLast().screenX  + gp.tileSizeWidth, gp.obj.getLast().screenY + gp.obj.getLast().hitBox[3], gp.tileSizeWidth + 16, gp.tileSizeHeight + 16);
		
		
		
		gp.obj.add(new OBJ_Table4Person("table4person", gp));
		gp.obj.getLast().screenX = gp.tileSizeWidth * 15;
		gp.obj.getLast().screenY = gp.tileSizeHeight * 10;
		gp.obj.getLast().placeCome = new Rectangle(gp.obj.getLast().screenX - gp.tileSizeWidth , gp.obj.getLast().screenY + gp.tileSizeHeight * 3, gp.tileSizeWidth + 16, gp.tileSizeHeight + 16);
		gp.obj.add(new OBJ_Table4Person("table4person", gp));
		gp.obj.getLast().screenX = gp.tileSizeWidth * 24;
		gp.obj.getLast().screenY = gp.tileSizeHeight * 10;
		gp.obj.getLast().placeCome = new Rectangle(gp.obj.getLast().screenX - gp.tileSizeWidth , gp.obj.getLast().screenY + gp.tileSizeHeight * 3, gp.tileSizeWidth + 16, gp.tileSizeHeight + 16);

		gp.chefs.add(new Chef(gp));
		gp.chefs.getLast().screenX = gp.tileSizeWidth * 22;
		gp.chefs.getLast().screenY = gp.tileSizeWidth * 1 + 16;
		gp.chefs.getLast().name = gp.chefs.getLast() + "0";
		
		for(int i = 0; i <gp.obj.size(); i++) {
			if(gp.obj.get(i).name == "table4person") {
				gp.obj.get(i).isService = 0;
			}
		}
		}
}
