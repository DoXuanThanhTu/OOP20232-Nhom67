package main;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.concurrent.TimeUnit;

import javax.swing.JButton;
import javax.swing.JPanel;

import ai.PathFinding;
import entity.Chef;
import entity.Customer;
import entity.Entity;
import entity.Menu;
import entity.Waiter;

import static entity.Chef.*;

import object.gameState;
import uiloadimage.loadImage;

public class GamePanel extends JPanel implements Runnable {
    public static int tileSizeWidth = 32;
    public static int tileSizeHeight = 32;
    public int colInDisplays = 36;
    public int rowInDisplays = 24;
    public int screenWidth = tileSizeWidth * colInDisplays;
    public int screenHeight = tileSizeHeight * rowInDisplays;
    public int totalChefsThread = 0;
    int screenWidth2 = screenWidth;
    int screenHeight2 = screenHeight;
    BufferedImage tempScreen;
    Graphics2D g2;
    public int dich = tileSizeHeight * 8;
    public int income = 0;
    public static int victoryState = 6;
    public static int defeatState = 7;

    public LogicGame lg = new LogicGame(this);
    public KeyInput key = new KeyInput(this);
    public MouseInput mouse = new MouseInput(this);
    public ArrayList<Customer> customers = new ArrayList<Customer>();
    public Waiter waiters = new Waiter(this, key);
    public ArrayList<Chef> chefs = new ArrayList<Chef>();
    public CollsionCheck collsionCheck = new CollsionCheck(this);
    public ArrayList<Entity> obj = new ArrayList<Entity>();
    public ArrayList<Entity> entityList = new ArrayList<Entity>();
    public AssetSetter assetSetter = new AssetSetter(this);
    public ArrayList<String> totalOrder = new ArrayList<String>();
    public ArrayList<Entity> allDishes = new ArrayList<Entity>();
    public ArrayList<Entity> panel = new ArrayList<Entity>();
    public ArrayList<Entity> item = new ArrayList<Entity>();
    public PathFinding pathFinding = new PathFinding(this);
    public gameState gs = new gameState(this);
    public drawGameState dgs = new drawGameState(this);
    final int maxInventory = 20;
    Sounds music = new Sounds();
    Sounds se = new Sounds();
    public UI ui = new UI(this);
    public Menu menu = new Menu();
    public loadImage loadui = new loadImage(this);
    Thread gameThread;
    int FPS = 60;
    public boolean checkDrawTime = false;
    int PlayerX = 100;
    int PlayerY = 100;
    int PlayerSpeed = 4;
    public int gameState;
    public int gameSence;
    public final static int menuStartState = 0;
    public final static int playState = 1;
    public final static int selectTable = 1;
    public final static int normalSence = 0;
    public final static int pauseState = 3;
    public final static int charaterState = 4;
    public final static int selectTableState = 5;
    public int totalCustomer = 0;
    public int timeSpawnCustomer = 0;
    public int time = 0;
    public int colorIndex = 0;
    int y = tileSizeWidth * 5;
    public int targetIncome = 200;
    public boolean isPaused = false;
    JButton button_start, button_resume, button_restart;
    public JButton button_nextDay;
    public int timeClock = 9;
    public int nhacNenOn = 0;
    public int nhacTinhTien = 0;
    private boolean victoryCheck = false;
    public int victorymusic = 0;

    public GamePanel() {
        setPreferredSize(new Dimension(screenWidth, screenHeight));
        setBackground(Color.black);
        tempScreen = new BufferedImage(screenWidth2, screenHeight2, BufferedImage.TYPE_INT_ARGB);
        g2 = (Graphics2D) getGraphics();
        setDoubleBuffered(true);
        addKeyListener(key);
        addMouseMotionListener(mouse);
        addMouseListener(mouse);
        setFocusable(true);
        initAllButton();
        gameSence = normalSence;
    }

    private void initAllButton() {
        button_resume = new JButton();
        button_resume.setBounds((int) (tileSizeWidth * 16), tileSizeHeight * 10, (int) (tileSizeWidth * 4), tileSizeHeight * 4);
        button_resume.setFocusPainted(false);      
        button_resume.setContentAreaFilled(false);  
        button_resume.setBorderPainted(false);     

        button_resume.setRolloverEnabled(false);    
        button_resume.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (e.getSource() == button_resume) {
                    gameState = playState;
                    isPaused = false;
                    synchronized (gameThread) {
                        gameThread.notify();
                    }
                    remove(button_resume);
                }
            }
        });
        
        button_nextDay = new JButton();
        button_nextDay.setBounds(560, 490, 140, 30);
        button_nextDay.setFocusPainted(false);       
        button_nextDay.setContentAreaFilled(false);  
        button_nextDay.setBorderPainted(false);      

        button_nextDay.setRolloverEnabled(false);    
        button_nextDay.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (e.getSource() == button_nextDay) {
                    gameState = playState;
                    income = 0;
                    targetIncome = targetIncome + 50;
                    isPaused = false;
                    System.out.println("next day");
                    remove(button_nextDay);
                }
            }
        });

        button_menu = new JButton();
        button_menu.setBounds(20, 20, ui.listImage.get(4).getWidth(), ui.listImage.get(4).getHeight());
        button_menu.setFocusPainted(false);       
        button_menu.setContentAreaFilled(false);  
        button_menu.setBorderPainted(false);      

        button_menu.setRolloverEnabled(false);    
        button_menu.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (e.getSource() == button_menu) {
                    gameState = pauseState;
                    synchronized (gameThread) {
                        isPaused = true;
                    }
                }
            }
        });
        button_start = new JButton();
        button_start.setBounds(848, 223, tileSizeWidth * 7, tileSizeHeight * 4);
        button_start.setFocusPainted(false);       
        button_start.setContentAreaFilled(false);  
        button_start.setBorderPainted(false);      

        button_start.setRolloverEnabled(false);   
        add(button_start);
        button_start.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (e.getSource() == button_start) {
                    gameState = playState;
                    remove(button_start);
                }
            }
        });
    }

    public void setUpgame() {
        assetSetter.loadObject();
        gameState = menuStartState;

        tempScreen = new BufferedImage(screenWidth2, screenHeight2, BufferedImage.TYPE_INT_ARGB);
        g2 = (Graphics2D) getGraphics();
        initAllButton();
    }

    public void startGameThread() {
        gameThread = new Thread(this);
        gameThread.start();
    }

    @Override
    public void run() {
        double framePerSecond = 1000000000 / FPS;
        double delta = 0;
        long lastCheck = System.nanoTime();
        long currentTime;
        long timer = 0;
        int drawCount = 0;
        while (gameThread != null) {
            synchronized (gameThread) {
                while (isPaused) {
                    try {
                        gameThread.wait();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
            currentTime = System.nanoTime();
            delta += (currentTime - lastCheck) / framePerSecond;
            timer += (currentTime - lastCheck);
            lastCheck = System.nanoTime();
            if (delta >= 1) {
                update();
                repaint();
                time++;
                delta--;
                drawCount++;
            }
            if (timer >= 1000000000) {
                drawCount = 0;
                timer = 0;
            }
        }
    }
	public void update() {
		if(gameState == victoryState && victorymusic <= 10 ) {
			playSE(4);
			victorymusic ++;
			isPaused = true;
		}
		if(key.vPressed == true) {
			gameState = victoryState;
		}
		lg.victory();
		lg.CustomerLogic();
		if (gameState == playState || gameState == selectTable && gameThread == null) {
			if(chefs.get(0).isRunning == false && chefs.get(0).chefAction == chefCook && chefs.get(0).dishesProgressbyChef.size() != 00 && totalChefsThread < 1) {
				chefs.get(0).startChefThread();
				totalChefsThread = 1;
				
			}
			removeAll();
		}
		if(nhacNenOn == 0 && gameState == playState) {
			playMusic(0);
			nhacNenOn = 1;
		}
	}
	
	public void resetGame() {
		System.out.println("rs");
	    customers.clear();
	    chefs.clear();
	    obj.clear();
	    entityList.clear();
	    allDishes.clear();
	    panel.clear();
	    item.clear();
	    totalOrder.clear();
	    
	    totalChefsThread = 0;
	    totalCustomer = 0;
	    timeSpawnCustomer = 0;
	    time = 0;
	    colorIndex = 0;
	    timeClock = 9;
	    nhacNenOn = 0;
	    nhacTinhTien = 0;
	    victorymusic = 0;
	    isPaused = false;
	    
	    assetSetter.loadObject(); 
	    music.stop(); 
	    
	    
	    add(button_nextDay);
	    add(button_resume);
	    add(button_menu);
	}

	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		
		Graphics2D g2 = (Graphics2D)g;
		
		g2.drawImage(gs.stageImg.get(1), 0, 0, screenWidth2, screenHeight2, null);
		
		entityList.add(waiters);
		for (int i = 0; i < obj.size(); i++) {
			entityList.add(obj.get(i));
			
		}
		
		Collections.sort(entityList, new Comparator<Entity>() {

			@Override
			public int compare(Entity o1, Entity o2) {
				// TODO Auto-generated method stub
				int result = Integer.compare(o1.screenY - 20, o2.screenY);
				return result;
			}
		});
		
		
		
		
		ui.draw(g2);
		if(gameState != menuStartState) {
			for(int i = 0; i < entityList.size(); i++) {
				if(entityList.get(i).name != "waiter")
				entityList.get(i).draw(g2);
			}
			ui.draw(g2);
			for(int i = 0; i < entityList.size(); i++) {
				entityList.remove(i);
			}

			for (int i = 0; i < chefs.size(); i ++) {
				chefs.get(i).draw(g2);
			}
			waiters.draw(g2);
		}
		
		for (int i = 0; i < customers.size(); i++) {
			if(customers.get(i).isDraw ) {
				customers.get(i).draw(g2);
			}
				totalCustomer = i;
		}
		
		if(gameState != menuStartState) {
			
		}
		dgs.drawVictoryState(g2);
		if (mouse.clickObj == true) {
			pathFinding.drawPath(g2);
		}
		
		
		if(gameState == playState) {
			if(time >= 0 && timeClock <= 22) {
				time ++;
				if(time >= 200) {
					timeClock++;
					time = 0;
				}
				if(timeClock >= 19 && time == 0 && timeClock <= 22) {
					colorIndex += 11;
				}
			}
			g2.setColor(new Color(0, 0, 0, colorIndex));
			g2.fillRect(0, 0,tileSizeWidth * 6, screenHeight);
		}
		else if(gameState != playState && gameState != menuStartState){
			g2.setColor(new Color(0, 0, 0, colorIndex));
			g2.fillRect(0, 0,tileSizeWidth * 6, screenHeight);
		}
		
		g2.dispose();
	}
	
	public void playMusic(int i) {
		
		music.setFile(i);
		music.loop();
	}
	public void stopMusic() {
		music.stop();
	}
	public void playSE(int i) {
		
		se.setFile(i);
		se.play();
		se.stopAfterDelay(3, TimeUnit.SECONDS);
	}
	
	public JButton button_menu;
	


}

