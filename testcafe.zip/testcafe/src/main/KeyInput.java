package main;

import java.awt.event.KeyEvent;

import java.awt.event.KeyListener;

import main.GamePanel;

public class KeyInput implements KeyListener {
	public boolean upPressed, downPressed, leftPressed, rightPressed;
	public boolean upReleased, downReleased, leftReleased, rightReleased;
	public boolean setRunning = false;
	public boolean checkDrawTime = false;
	public boolean cPressed,pPressed;
	GamePanel gp;
	public boolean enterPressed;
	public boolean vPressed;
	public KeyInput(GamePanel gp) {
		this.gp = gp;
	}
	public void characterState(int code) {
		if (code == KeyEvent.VK_LEFT || code == KeyEvent.VK_A) {
			if (gp.ui.curcol != 0) {
				gp.ui.curcol--;
			}
		}else if (code == KeyEvent.VK_RIGHT || code == KeyEvent.VK_D) {
			if (gp.ui.curcol != 4) {
				gp.ui.curcol++;
			}
		}else if (code == KeyEvent.VK_UP || code == KeyEvent.VK_W) {
			if(gp.ui.currow != 0) {
				gp.ui.currow--;
			}
		}else if (code == KeyEvent.VK_DOWN || code == KeyEvent.VK_S) {
			if (gp.ui.currow != 3) {
				gp.ui.currow++;
			}
		}else if (code == KeyEvent.VK_B || code == KeyEvent.VK_ESCAPE) {
			gp.gameState = gp.playState;
		}else if (code == KeyEvent.VK_ENTER && enterPressed == false) {
			enterPressed  = true;
		}else if (code == KeyEvent.VK_ENTER && enterPressed == true) {
			enterPressed = false;
		}
	}
	public void playState(int code) {
		if(code == KeyEvent.VK_V) {
			vPressed = true;
		}

	}
	public void pauseState(int code) {
		if (code == KeyEvent.VK_P) {
			gp.gameState = gp.playState;
		}
	}
	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		int code = e.getKeyCode();
		if (gp.gameState == gp.playState) {
			playState(code);
		}else if (gp.gameState == gp.charaterState) {
			characterState(code);
		}else if (gp.gameState == gp.pauseState) {
			pauseState(code);
		}
			if (code == KeyEvent.VK_C) {
				cPressed = true;
			}
		
		}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		int code = e.getKeyCode();
		if (code == KeyEvent.VK_W) {
			upPressed = false;
		}
		if (code == KeyEvent.VK_S) {
			downPressed = false;
			
		}
		if (code == KeyEvent.VK_A) {
			leftPressed = false;
		}
		if (code == KeyEvent.VK_D) {
			rightPressed = false;
		}
	}
	
}
