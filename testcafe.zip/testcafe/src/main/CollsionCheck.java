package main;

import java.awt.Rectangle;

import java.util.ArrayList;

import entity.Entity;
import main.GamePanel;

public class CollsionCheck {
	GamePanel gp;
	Entity entity;
	public CollsionCheck(GamePanel gp){
		this.gp = gp;
	}
	
	public int checkObject(Entity entity, boolean isPlayer) {
		int index = 9999;
		
		for (int i = 0; i < gp.obj.size(); i++) {
			int entityLeftscreenX =  entity.locationHitBox[0];
			int entityTopscreenY =  entity.locationHitBox[1];
			Rectangle entityHitBox = new Rectangle(entityLeftscreenX, entityTopscreenY, entity.locationHitBox[2], entity.locationHitBox[3]);
			int objX = gp.obj.get(i).screenX;
			int objY = gp.obj.get(i).screenY;
			Rectangle hitBoxObject = new Rectangle(objX + gp.obj.get(i).hitBox[0],objY + gp.obj.get(i).hitBox[1], gp.obj.get(i).hitBox[2],gp.obj.get(i).hitBox[3]);
			
			switch(entity.direction) {
			case "up" :
				entityHitBox.y -= entity.speed;
				if(entityHitBox.intersects(hitBoxObject)) {
					if(gp.obj.get(i).collison == true) {
						entity.collisionOn = true;
					}
					if(isPlayer == true) {
						index = i;
					}
					
				}
				break;
			case "down" :
				entityHitBox.y += entity.speed;
				if(entityHitBox.intersects(hitBoxObject)) {
					if(gp.obj.get(i).collison ==true) {
						entity.collisionOn = true;
					}
					if(isPlayer == true) {
						index = i;
					}
				}
				break;
			case "left" :
				entityHitBox.x -= entity.speed;
				if(entityHitBox.intersects(hitBoxObject)) {
					if(gp.obj.get(i).collison ==true) {
						entity.collisionOn = true;
					}
					if(isPlayer == true) {
						index = i;
					}
				}
				break;
			case "right" :
				entityHitBox.x += entity.speed;
				if(entityHitBox.intersects(hitBoxObject)) {
					if(gp.obj.get(i).collison ==true) {
						entity.collisionOn = true;
					}
					if(isPlayer == true) {
						index = i;
					}
				}
				break;
			}
		}
		return index;
	}

}
