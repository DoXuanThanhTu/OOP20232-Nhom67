package main;


import java.awt.Cursor;

import javax.swing.JFrame;
import javax.swing.JRootPane;

import main.MouseImage;

import main.GamePanel;

public class Main extends JFrame {
	public MouseImage mi = new MouseImage();
	public static JFrame window;
	public Main() {
		window = this;
		// TODO Auto-generated constructor stub
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(false);
		setUndecorated(false);
		setTitle("2D Game");
		
		GamePanel gamePanel = new GamePanel();
		add(gamePanel);

		pack();
		setLocationRelativeTo(null);
		setVisible(true);
		gamePanel.setUpgame();
		gamePanel.startGameThread();
	}
	public static void main(String[] args) {
		new Main();
	}
}
