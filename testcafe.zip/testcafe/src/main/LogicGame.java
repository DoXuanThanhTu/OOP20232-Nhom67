package main;

import java.awt.Rectangle;
import java.util.ListIterator;
import entity.Customer;
import entity.Entity;
import main.GamePanel;
import main.FoodItem;

import static entity.Customer.*;
import static main.GamePanel.*;

public class LogicGame {
    GamePanel gp;
    public int spawnTime = 0;
    public int maxWait = 4;
    int ac = 0;
    public int energy = 0;
    public int vic = 1;

    public LogicGame(GamePanel gp) {
        this.gp = gp;
    }

    public void CustomerLogic() {
        spawnTime++;
        if (spawnTime == 300 && maxWait >= 0 && gp.timeClock <= 20) {
            gp.customers.add(new Customer(gp));
            gp.customers.getLast().customerAction = outSide;
            gp.customers.getLast().maxY = gp.tileSizeHeight * 14 - (12 - maxWait * 3) * 32;
            spawnTime = 0;
            maxWait--;
        }

        if (gp.gameState == playState && gp.customers.size() > 0) {
            Customer cus = null;

            for (int i = 0; i < gp.obj.size(); i++) {
                if (gp.obj.get(i).name.equals("table4person") && gp.obj.get(i).service != null) {
                    cus = gp.obj.get(i).service;
                }
                if (cus != null && cus.doneChange) {
                    cus.customerAction = sittingChair;
                    if (cus.customerAction != outSide) {
                        cus.actionCounter++;
                        if (cus.hasOrder && cus.customerOrder.isEmpty()) {
                            cus.customerAction = eat;
                            cus.animationSpeed = 15;
                            ac++;
                            if (ac > 100 && ac < 300) {
                                cus.customerAction = like;
                            } else if (ac >= 300) {
                                cus.done = 4;
                                cus.animationSpeed = 7;
                                ac = 0;
                            }
                        } else if (cus.hasOrder) {
                            cus.customerAction = sittingChair;
                        }

                        if (cus.actionCounter >= 0 && !cus.hasOrder && cus.actionCounter < 120) {
                            gp.gameSence = normalSence;
                            cus.customerAction = getMenu;
                            gp.waiters.goalReach = false;
                        }

                        if (cus.actionCounter >= 120 && !cus.hasOrder) {
                            cus.customerAction = order;
                        }

                        if (gp.mouse.previousObjIndex != 9999 && gp.waiters.onYourWay == 1 &&
                                "table4person".equals(gp.obj.get(gp.mouse.previousObjIndex).name) &&
                                cus.actionCounter > 120) {

                            Rectangle rec = gp.obj.get(gp.mouse.previousObjIndex).placeCome;
                            if (!cus.hasOrder && cus.isDraw && (rec.intersects(gp.waiters.hitBox) || rec.contains(gp.waiters.hitBox)) &&
                                    gp.obj.get(gp.mouse.previousObjIndex).service == cus && gp.waiters.getFoodItem[0] == null && gp.waiters.getFoodItem[1] == null) {

                                cus.placeOrders();
                                gp.waiters.orders.addAll(cus.customerOrder);
                                cus.orderChanged = true;
                                cus.hasOrder = true;
                                cus.orderInProcess = false;
                            }

                            if (gp.mouse.previousObjIndex != 9999 && !cus.customerOrder.isEmpty() &&
                                    (rec.intersects(gp.waiters.hitBox) || rec.contains(gp.waiters.hitBox)) &&
                                    gp.obj.get(gp.mouse.previousObjIndex).service == cus) {

                                ListIterator<FoodItem> orderIterator = cus.customerOrder.listIterator();
                                while (orderIterator.hasNext() && gp.waiters.goalReach) {
                                    FoodItem order = orderIterator.next();
                                    if (gp.waiters.getFoodItem[0] != null && order.getFoodName().equals(gp.waiters.getFoodItem[0].getFoodName())) {
                                        gp.waiters.getFoodItem[0] = null;
                                        gp.waiters.max_get += 1;
                                        orderIterator.remove();
                                        gp.ui.energystatus += 32;
                                        cus.orderChanged = true;
                                    } else if (gp.waiters.getFoodItem[1] != null && order.getFoodName().equals(gp.waiters.getFoodItem[1].getFoodName())) {
                                        gp.waiters.getFoodItem[1] = null;
                                        gp.waiters.max_get += 1;
                                        orderIterator.remove();
                                        cus.orderChanged = true;
                                        gp.ui.energystatus += 32;
                                    }
                                }
                                gp.mouse.clickTable4Person = false;
                            }

                        }
                        if (cus.leave()) {
                            for (Entity table : gp.obj) {
                                if (table.service == cus) {
                                    table.service = null; // Free the table
                                    table.isService = 0;
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        }

        victory();
    }

    public void victory() {
        boolean allCustomersLeft = true;
        for (Customer customer : gp.customers) {
            if (customer.isDraw) {
                allCustomersLeft = false;
                break;
            }
        }
        System.out.println(allCustomersLeft +" " + gp.customers.size());
        if (allCustomersLeft && gp.customers.size() != 0 && gp.income >= gp.targetIncome) {
            System.out.println("All customers have left. Game state set to victoryState."); 
            gp.gameState = gp.victoryState;
        }
    }

    public boolean checkValue() {
        return (gp.mouse.objIndex != 9999 && gp.mouse.cusIndex != 9999);
    }
}
