
package main;

import static main.GamePanel.*;


import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Set;
import java.util.function.LongPredicate;

import javax.imageio.ImageIO;

import entity.Customer;
import entity.Entity;
import main.GamePanel;
import object.OBJ_Table4Person;

public class UI {
	GamePanel gp;
	public Graphics2D g2;
	Font arial_40 ,arial_80B;
	Font arial_16B ;
	public boolean messageOn = false;
	public String message = "";
	int messageCounter = 0;
	public boolean gameFinished = false;
	double playTime = 0;
	DecimalFormat df = new DecimalFormat("#0.00");
	public int  Uipaint = 0;
	public int update = 0;
	 Font arial_10;
	 public int curcol = 0;
	 public int currow = 0;
	 public ArrayList<BufferedImage> listImage = new ArrayList<BufferedImage>();
	public double energystatus = 0;
//	 loadImage li = new loadImage(this);
	 
	public UI(GamePanel gp) {
		this.gp = gp;
		arial_10 = new Font("Arial", Font.BOLD, 10);
		arial_40 = new Font("Arial", Font.PLAIN, 40);
		arial_80B = new Font("Arial", Font.BOLD, 80);
		arial_16B = new Font("Arial", Font.BOLD, 16);
		initListImage();
		
	}
	private void initListImage() {
	// TODO Auto-generated method stub
		ArrayList<InputStream> iss = new ArrayList<InputStream>();
		iss.add(getClass().getResourceAsStream("/ui/money2.png"));
		iss.add(getClass().getResourceAsStream("/ui/Nangluong.png"));
		iss.add(getClass().getResourceAsStream("/ui/energyicon.png"));
		iss.add(getClass().getResourceAsStream("/ui/energystatus.png"));
		iss.add(getClass().getResourceAsStream("/ui/menuButton.png"));
		try {
			for (int i = 0; i < iss.size(); i++) {
				BufferedImage img = ImageIO.read(iss.get(i));
				listImage.add(img);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
}
	public void showMessage(String message) {
		this.message = message;
		this.messageOn = true;
	}
	public void draw(Graphics2D g2) {
		this.g2 = g2;
		if(energystatus >= gp.tileSizeHeight * 3) {
			energystatus = gp.tileSizeHeight * 3;
			gp.waiters.speed = 5;
		}
		if(gp.gameState == playState || gp.gameState == selectTableState) {
			for(int i = 0; i < gp.obj.size(); i++) {
				if (gp.obj.get(i).name == "table4person" && gp.obj.get(i).service != null) {
					drawOrderSideTable(gp.obj.get(i));
				}
			}
			
				drawDishesProgressbyChef();
				drawDishesCompletedChef();
				drawUIinPlayState();
		}
		
		if (gp.gameState == charaterState) {
			drawInventory();
			if (gp.key.enterPressed == true) {
				drawItemHitBox();
			}
		}
		if (gp.gameState == menuStartState) {
			drawMenuStartState();
		}
		
		
	}
	public void drawVictoryState(Graphics2D g2) {

	}
	
private void drawDishesProgressbyChef() {
		// TODO Auto-generated method stub
	for(int i = 0; i < gp.chefs.size(); i++) {
		if(gp.chefs.get(i).dishesProgressbyChef.size() != 0) {
	        int maxItemsToShow = 8;
	        int xPosition = gp.tileSizeWidth * 35;
	        int yPosition = gp.tileSizeHeight * 6;
	        for (int j = 0; j < Math.min(maxItemsToShow, gp.chefs.get(i).dishesProgressbyChef.size()); j++) {
	        	drawSubWindow(xPosition, yPosition, 48, 48);
	            g2.drawImage(gp.chefs.get(i).dishesProgressbyChef.get(j).getImage(), xPosition + 4, yPosition + 4,24,24, null );
	            yPosition += gp.tileSizeWidth /3 + gp.tileSizeWidth;
	        }
	        
		}
	}
	
		int xPosition2 = gp.tileSizeWidth * 27;
        int yPosition2 = gp.tileSizeHeight * 0;
		if(gp.waiters.getFoodItem[0] != null) {
			drawSubWindow(xPosition2, yPosition2, 48, 48);
            g2.drawImage(gp.waiters.getFoodItem[0].getImage(), xPosition2 + 8, yPosition2 + 8,24,24, null );
		}
		if (gp.waiters.getFoodItem[1] != null) {
			drawSubWindow(xPosition2 + 48, yPosition2, 48, 48);
            g2.drawImage(gp.waiters.getFoodItem[1].getImage(), xPosition2 + 8 + 48, yPosition2 + 8,24,24, null );
		}
	
	}
private void drawDishesCompletedChef() {
		// TODO Auto-generated method stub
	for(int i = 0; i < gp.chefs.size(); i++) {
		if(gp.chefs.get(i).dishCompleted.size() != 0) {
	        int maxItemsToShow = 3;
	       
	        
	        int xPosition = gp.chefs.get(i).screenX - gp.tileSizeWidth / 2 - gp.tileSizeWidth;
	        int yPosition = gp.chefs.get(i).screenY + gp.chefs.get(i).chefHeight + gp.tileSizeHeight /2;
	        for (int j = 0; j < Math.min(maxItemsToShow, gp.chefs.get(i).dishCompleted.size()); j++) {
	        	g2.setColor(Color.white);
	        	if(gp.chefs.get(i).dishCompleted.get(j).getFoodName() != "Wine")
	        	g2.drawImage(gp.chefs.get(i).dishCompleted.get(j).getPlate(), xPosition, yPosition,32,32, null );
	            g2.drawImage(gp.chefs.get(i).dishCompleted.get(j).getImage(), xPosition + 4, yPosition + 4,24,24, null );
	            xPosition += gp.tileSizeWidth /3 + gp.tileSizeWidth;
	        }
	        
		}
	}
}
	private void drawMenuStartState() {
		// TODO Auto-generated method stub
			g2.drawImage(gp.gs.stageImg.get(0), 0, 0, gp.screenWidth2, gp.screenHeight2, null);
	}
	private void drawInventory() {
		// TODO Auto-generated method stub
		int frameX = gp.tileSizeWidth * 10;
		int frameY = gp.tileSizeHeight * 3;
		int frameWidth = gp.tileSizeWidth * 12;
		int frameHeight = gp.tileSizeHeight * 10;
		drawSubWindow(frameX, frameY, frameWidth, frameHeight);
		
		final int slotXStart = frameX + 32;
		final int slotYStart = frameY + 32;
		int slotX = slotXStart;
		int slotY = slotYStart;
		
		//Cursor
		int cursorX = slotXStart + (gp.tileSizeWidth * 2 * curcol);
		int cursorY = slotYStart + (gp.tileSizeHeight  * 2* currow);
		int cursorWidth = gp.tileSizeWidth * 2;
		int cursorHeight = gp.tileSizeHeight * 2;
		g2.setStroke(new BasicStroke(3));
		g2.drawRoundRect(cursorX, cursorY, cursorWidth, cursorHeight, 10, 10);
		
		//draw item
		for (int i = 0; i < gp.item.size(); i++) {
			g2.drawImage(gp.item.get(i).image, slotX, slotY, cursorWidth, cursorHeight, null);
			slotX += gp.tileSizeWidth * 2;
			if (i % 5 == 4) {
				slotX = slotXStart;
				slotY += gp.tileSizeHeight * 2;
			}
		}
		//description frame
		int dFrameX = frameX;
		int dFrameY = frameY + frameHeight;
		int dFrameWidth = frameWidth;
		int dFrameHeight = frameHeight / 2;
		
		
		//description text
		int textX = dFrameX + 32;
		int textY = dFrameY + 32;
		g2.setFont(arial_16B);
		
		int itemIndex = getItemIndex();
		if (itemIndex < gp.item.size()) {
			drawSubWindow(dFrameX, dFrameY, dFrameWidth, dFrameHeight);
			for (String line : gp.item.get(itemIndex).description.split("\n")) {
				g2.drawString(line,textX, textY);
				textY += 32;
			}
		}
	}
	
	public int getItemIndex() {
		return curcol + (currow * 5);
	}
	public void drawItemHitBox() {
		int x = gp.mouse.x;
		int y = gp.mouse.y;
		
		g2.setStroke(new BasicStroke(0));
		Rectangle rc = new Rectangle(x, y, gp.tileSizeWidth, gp.tileSizeHeight);
		int itemIndex = getItemIndex();
		if (itemIndex < gp.item.size()) {
			BufferedImage img = gp.item.get(itemIndex).image;
		g2.drawImage(img, x, y,img.getWidth() * 2, img.getHeight() * 2, null );
		
		}
		
	}
	public void setObject() {
		int itemIndex = getItemIndex();
		if (itemIndex < gp.item.size()) {
		gp.obj.get(gp.obj.size() - 1).screenX = gp.mouse.x;
		gp.obj.get(gp.obj.size() - 1).screenY = gp.mouse.y;
		}
	}
	
	private void drawUIinPlayState() {
		g2.drawImage(listImage.get(0), gp.tileSizeWidth * 7, 0, gp.tileSizeWidth * 4, gp.tileSizeHeight * 2, null);
		g2.drawImage(listImage.get(0), gp.tileSizeWidth * 11, 0, gp.tileSizeWidth * 4, gp.tileSizeHeight * 2, null);
		g2.drawImage(listImage.get(0), gp.tileSizeWidth * 15, 0, gp.tileSizeWidth * 4, gp.tileSizeHeight * 2, null);
		g2.setColor(new Color(255, 255, 0, 200));
		g2.fillRoundRect(500, 20, (int)energystatus , 28,20,20);
		
		g2.drawImage(listImage.get(2), gp.tileSizeWidth * 15, 5,listImage.get(2).getWidth(), listImage.get(2).getHeight() , null);
		g2.setFont(new Font("Arial",Font.BOLD, 22));
		g2.setColor(Color.GREEN);
		g2.drawString("$" + String.valueOf(gp.income),  (int)(gp.tileSizeWidth * 8), (int)(gp.tileSizeHeight * 1.3));
		g2.setColor(Color.ORANGE);
		g2.drawString("$" + String.valueOf(gp.targetIncome),  (int)(gp.tileSizeWidth * 12), (int)(gp.tileSizeHeight * 1.3));
		

		
	}
	
	public void drawSubWindow(int x, int y, int width, int height) {
		Color c = new Color(255, 255, 255, 200);
		g2.setColor(c);
		g2.fillRoundRect(x, y, width, height, 10, 10);
	}

	public boolean drawOrderSideTable(Entity en) {
						Customer cus = en.service;
						if(cus != null) {
					if (cus.orderChanged || cus.customerOrder.size() != 0 && cus.isDraw ) {
			            int maxItemsToShow = 4;
			            int yPosition = en.screenY ;
			            int y2Position = (int) (en.screenY);
			            for (int i = 0; i < 4;i++) {
			            	drawSubWindow(en.screenX + en.hitBox[2], y2Position + gp.tileSizeHeight, 32, 32);
			      
			                
			                y2Position += gp.tileSizeHeight;
			            }
			            y2Position = (int) (en.screenY);
			            for (int i = 0; i < Math.min(maxItemsToShow, cus.customerOrder.size()); i++) {
			            	if(cus.customerOrder.get(i).getFoodName() != "Wine")
			            	g2.drawImage(cus.customerOrder.get(i).getPlate(), en.screenX + en.hitBox[2] , y2Position + gp.tileSizeHeight,32,32, null );
			                g2.drawImage(cus.customerOrder.get(i).getImage(), en.screenX + en.hitBox[2] + 4, y2Position + gp.tileSizeHeight + 4,24,24, null );
			                
			                yPosition += gp.tileSizeHeight * 2;
			                y2Position += gp.tileSizeHeight;
			                
			            }
			            cus.orderChanged = false;
			            
			            return true;
			        }
						}
					return false;
	}
}
