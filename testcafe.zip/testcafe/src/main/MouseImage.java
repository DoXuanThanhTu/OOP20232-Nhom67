package main;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.io.*;
import javax.imageio.*;

public class MouseImage extends JFrame {

    private Cursor cursor1;
    private Cursor cursor2;

    public MouseImage () {

        BufferedImage cursorImage1 = null;
        BufferedImage cursorImage2 = null;
        try {
            cursorImage1 = ImageIO.read(getClass().getResource("/mouse/normal.png"));
            cursorImage2 = ImageIO.read(getClass().getResource("/mouse/select.png"));
        } catch (IOException e) {
            e.printStackTrace();
            System.exit(1);
        }

        // Create the custom cursors
        Point hotspot = new Point(0, 0); // Adjust the hotspot as needed
        cursor1 = Toolkit.getDefaultToolkit().createCustomCursor(cursorImage1, hotspot, "Cursor 1");
        cursor2 = Toolkit.getDefaultToolkit().createCustomCursor(cursorImage2, hotspot, "Cursor 2");

    }

    public Cursor getCursor1() {
		return cursor1;
	}

	public void setCursor1(Cursor cursor1) {
		this.cursor1 = cursor1;
	}

	public Cursor getCursor2() {
		return cursor2;
	}

	public void setCursor2(Cursor cursor2) {
		this.cursor2 = cursor2;
	}

}