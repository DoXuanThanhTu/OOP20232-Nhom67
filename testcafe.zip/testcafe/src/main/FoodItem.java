package main;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;

import javax.imageio.ImageIO;


public class FoodItem {
	private BufferedImage image;
    private String foodName;
    private int preparationTime; 
    private double price; 
    private BufferedImage plate;
    public int type;

    public FoodItem(String foodName, int preparationTime, double price) {
        this.foodName = foodName;
        this.preparationTime = preparationTime;
        this.price = price;
        loadImage(this.foodName);
    }

    public String getFoodName() {
        return foodName;
    }

   

    public double getPrice() {
        return price;
    }

    @Override
    public String toString() {
        return "Name :" + foodName +" Preparation Time: " + preparationTime + " minutes, Price: $" + price +"\n";
    }

	public int getPreparationTime() {
		// TODO Auto-generated method stub
		return preparationTime;
	}
	
	public BufferedImage getImage() {
		return image;
	}

	public void setImage(BufferedImage image) {
		this.image = image;
	}

	public BufferedImage getPlate() {
		return plate;
	}

	public void setPlate(BufferedImage plate) {
		this.plate = plate;
	}

	public boolean isCompleted(FoodItem fi) {
		long lastCheck = System.currentTimeMillis();
		int needTime = 0;
		int timeToCook = 0;
		
		
	    			timeToCook = fi.getPreparationTime();
	    			
	    
	    	
	    	while(true) {
	    		long current = System.currentTimeMillis();
	    		if ((current - lastCheck) > timeToCook * 1000) {
		    		System.out.println(fi.getFoodName() + " is completed");
//		    		completed = true;
		    		return true;
		    	}
		    		needTime = (int) ((lastCheck + timeToCook * 1000 - current)/1000);
	    	}
		}
	public void loadImage(String name) {
		try {
			image = ImageIO.read(getClass().getResourceAsStream("/food/" + name +".png"));
			plate = ImageIO.read(getClass().getResourceAsStream("/object/plate.png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
}