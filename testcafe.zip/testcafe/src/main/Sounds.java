package main;

import java.io.IOException;
import java.net.URL;
import javax.sound.sampled.*;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class Sounds {
    Clip clip;
    URL soundURL[] = new URL[30];
    ScheduledExecutorService scheduler;

    public Sounds() {
        soundURL[0] = getClass().getResource("/sounds/nhac nen.wav");
        soundURL[1] = getClass().getResource("/sounds/click.wav");
        soundURL[2] = getClass().getResource("/sounds/click chuot.wav");
        soundURL[3] = getClass().getResource("/sounds/am thanh thua khi ket man.wav");
        soundURL[4] = getClass().getResource("/sounds/thang khi ket man.wav");
        soundURL[5] = getClass().getResource("/sounds/chuong bam.wav");
        soundURL[6] = getClass().getResource("/sounds/tinh tien.wav");
        
        scheduler = Executors.newScheduledThreadPool(1);
    }

    public void setFile(int i) {
        try {
            if (clip != null && clip.isRunning()) {
                clip.stop();
                clip.close();
            }
            AudioInputStream ais = AudioSystem.getAudioInputStream(soundURL[i]);
            clip = AudioSystem.getClip();
            clip.open(ais);

            // Đăng ký LineListener để lắng nghe sự kiện kết thúc và đóng clip
            clip.addLineListener(event -> {
                if (event.getType() == LineEvent.Type.STOP) {
                    clip.close(); // Đóng clip khi kết thúc
                }
            });
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
            e.printStackTrace();
        }
    }

    public void play() {
        if (clip != null) {
            clip.start();
        }
    }

    public void loop() {
        if (clip != null) {
            clip.loop(Clip.LOOP_CONTINUOUSLY);
        }
    }

    public void stop() {
        if (clip != null) {
            clip.stop();
        }
    }

   
    public void stopAfterDelay(long delay, TimeUnit unit) {
        scheduler.schedule(this::stop, delay, unit);
    }

    public void shutdown() {
        scheduler.shutdown();
        if (clip != null) {
            clip.close();
        }
    }
}
