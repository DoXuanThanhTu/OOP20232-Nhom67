package entity;
import java.awt.image.BufferedImage;
import main.FoodItem;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

import javax.imageio.ImageIO;

public class Menu {
    private ArrayList<FoodItem> appetizers; 
    private ArrayList<FoodItem> mainCourses; 
    private ArrayList<FoodItem> desserts;
    private ArrayList<FoodItem> drinks; 

    public Menu() {
        this.appetizers = new ArrayList<FoodItem>();
        this.mainCourses = new ArrayList<FoodItem>();
        this.desserts = new ArrayList<FoodItem>();
        this.drinks = new ArrayList<FoodItem>();
        initializeMenu();
    }

    public ArrayList<FoodItem> getAppetizers() {
        return appetizers;
    }

    public void setAppetizers(ArrayList<FoodItem> appetizers) {
        this.appetizers = appetizers;
    }

    public ArrayList<FoodItem> getMainCourses() {
        return mainCourses;
    }

    public void setMainCourses(ArrayList<FoodItem> mainCourses) {
        this.mainCourses = mainCourses;
    }

    public ArrayList<FoodItem> getDesserts() {
        return desserts;
    }

    public void setDesserts(ArrayList<FoodItem> desserts) {
        this.desserts = desserts;
    }

    public ArrayList<FoodItem> getDrinks() {
        return drinks;
    }

    public void setDrinks(ArrayList<FoodItem> drinks) {
        this.drinks = drinks;
    }

    public int getSizeAppetizers() {
        return appetizers.size();
    }

    public int getSizeMainCourses() {
        return mainCourses.size();
    }

    public int getSizeDesserts() {
        return desserts.size();
    }

    public int getSizeDrinks() {
        return drinks.size();
    }

    private void initializeMenu() {
        appetizers.add(new FoodItem("salad", 3, 5)); 
        
        mainCourses.add(new FoodItem("beefsteak", 5, 20)); 
        mainCourses.add(new FoodItem("fried chicken", 5, 10)); 
        mainCourses.add(new FoodItem("fried shrimp", 5, 5)); 
        mainCourses.add(new FoodItem("kimbap", 2, 5)); 
        mainCourses.add(new FoodItem("burger", 5, 5)); 
        mainCourses.add(new FoodItem("pizza", 5, 5)); 
        mainCourses.add(new FoodItem("king crab steamed with beer", 7, 5)); 
        
        desserts.add(new FoodItem("soup", 2, 4)); 
        desserts.add(new FoodItem("waffles", 2, 4)); 
        desserts.add(new FoodItem("tart", 2, 4)); 
        desserts.add(new FoodItem("cream", 2, 4)); 
        desserts.add(new FoodItem("chip", 2, 4)); 
        
        drinks.add(new FoodItem("Wine", 1, 20)); 
    }

    public FoodItem getFoodItemDetails(String foodName) {
        FoodItem item = findFoodItem(foodName);
           return item;
    }

    private FoodItem findFoodItem(String foodName) {
        for (FoodItem item : appetizers) {
            if (item.getFoodName().equalsIgnoreCase(foodName)) {
                return item;
            }
        }
        for (FoodItem item : mainCourses) {
            if (item.getFoodName().equalsIgnoreCase(foodName)) {
                return item;
            }
        }
        for (FoodItem item : desserts) {
            if (item.getFoodName().equalsIgnoreCase(foodName)) {
                return item;
            }
        }
        for (FoodItem item : drinks) {
            if (item.getFoodName().equalsIgnoreCase(foodName)) {
                return item;
            }
        }
        return null;
    }

}



