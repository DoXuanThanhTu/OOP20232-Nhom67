package entity;


import ai.Node;

import main.FoodItem;
import main.GamePanel;

import static main.GamePanel.*;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;

import javax.imageio.ImageIO;

import main.CollsionCheck;
import main.KeyInput;
import object.gameState;

public class Waiter extends Entity{
	KeyInput key;
	public int objIndex;
	int type = 5;
	String WaiterSpriteIdle = "Waiter.png";
	BufferedImage[] animationIdle, animationWalking, animationGetOrder;
	int animationTick = 0;
	int animationSpeed = 8;
	int animationIndex = 0;
	int upIdleIndex = 0;
	int leftIdleIndex = 4;
	int rightIdleIndex = 8;
	int downIdleIndex = 12;
	int upWalkingIndex = 0;
	int leftWalkingIndex = 4;
	int rightWalkingIndex = 8;
	int downWalkingIndex = 12;
	String WaiterAction;
	public int hasKey = 0;
	public double WaiterScale = 4;
	public int WaiterWidth;
	public int WaiterHeight;
	public double hitBoxScale = 1.5;
	public int onYourWay = 0;
	private boolean doublePressed;
	public  boolean goalReach;
	public FoodItem[] getFoodItem = new FoodItem[2];
	public int max_get = 2;
	public Rectangle hitBox ;
	public ArrayList<FoodItem> orders = new ArrayList<FoodItem>();
	public Waiter(GamePanel gp, KeyInput key) {
		
		super(gp);
		this.key = key;
		onPath = false;
		WaiterWidth =64;
		WaiterHeight =96;
		setDefaultValues();
		
		animationIdle = loadAnimation(WaiterSpriteIdle);
		}
	public void setDefaultValues() {
		screenX = gp.tileSizeWidth * 10;
		screenY = gp.tileSizeHeight * 4;
		name = "waiter";
		speed = 4;
		direction = "down";
		WaiterAction = "idle";
		locationHitBox[0] = screenX + 24 ;
		locationHitBox[1] = screenY + 80;
		locationHitBox[2] = 16;
		locationHitBox[3] = 16;
	}
		
	public BufferedImage GetSpriteAlats(String fileName) {
			BufferedImage img = null;
			try {
				img = ImageIO.read(getClass().getResourceAsStream("/npc/" + fileName));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return img;
		}
	public int setAction(String action) {
		this.WaiterAction = action;
			if(gp.mouse.objIndex != 9999 || gp.mouse.clickObj) {
				onYourWay = 0;
			}
			if (onYourWay == 0 ) {
					int objIndex = gp.mouse.previousObjIndex;
					if (objIndex != 9999 ) {
						int leftObj = (int)gp.obj.get(objIndex).placeCome.getX() / 32;
						int bottomObj =(int) gp.obj.get(objIndex).placeCome.getY() / 32;
						searchPath(objIndex);
						
					}
			if(gp.gameState == selectTableState) {
				onYourWay = 1;
			}			
			
			}
				return objIndex;
	}
	public boolean getDishCompleted() {
	    if (!gp.chefs.get(0).dishCompleted.isEmpty() && max_get != 0 && gp.mouse.previousObjIndex != 9999 && gp.mouse.clickChefTable) {
        	Rectangle rec = gp.obj.get(gp.mouse.previousObjIndex).placeCome;
        	System.out.println(rec.contains(hitBox) + " " + rec.intersects(hitBox));
	        Iterator<FoodItem> iterator = gp.chefs.get(0).dishCompleted.iterator();
	        if (iterator.hasNext()  && (rec.intersects(hitBox) || rec.contains(hitBox))) {
	            if (max_get == 2) {
	                getFoodItem[0] = iterator.next();
	                gp.chefs.get(0).getMoney += getFoodItem[0].getPrice();
	                max_get = 1;
	            } else if (max_get == 1) {
	                getFoodItem[1] = iterator.next();
	                gp.chefs.get(0).getMoney += getFoodItem[1].getPrice();
	                max_get = 0;
	            }
	            gp.mouse.clickChefTable = false;
	            iterator.remove();
	            return true;
	        }
	    }
	    return false;
	}


	public void update() {
		if(gp.waiters.speed == 5) {
			gp.ui.energystatus-= 0.2f;
			if(gp.ui.energystatus <= 0) {
				gp.waiters.speed = 4;
				gp.ui.energystatus = 0;
			}
			setAction(WaiterSpriteIdle);
			if(goalReach && onYourWay == 1) {
				gp.mouse.objIndex = 9999;
			}
			
			if (getDishCompleted()) {
				
			}
			locationHitBox[0] = screenX + 24 ;
			locationHitBox[1] = screenY + 80;
			hitBox = new Rectangle(locationHitBox[0], locationHitBox[1], 16, 16);

			}
		setAction(WaiterSpriteIdle);
		if(goalReach && onYourWay == 1) {
			gp.mouse.objIndex = 9999;
		}
		
		if (getDishCompleted()) {
			
		}
		
		
		collisionOn = false;	
		objIndex = gp.collsionCheck.checkObject(this, true);
		
			
			if ((key.upPressed && key.downPressed) || (key.leftPressed && key.rightPressed))
			{
			doublePressed = true;
			}
			else if(key.upPressed && !key.downPressed) {
				direction = "up";
				setAction(WaiterSpriteIdle);
				doublePressed = false;
				
			}
			else if(key.downPressed && !key.upPressed) {
				direction = "down";
				doublePressed = false;
			}
			else if(key.rightPressed && !key.leftPressed ) {
				direction = "right";
				doublePressed = false;
			}
			else if(key.leftPressed && !key.rightPressed) {
				direction = "left";
				doublePressed = false;
		}
		if (collisionOn == false && (key.upPressed || key.downPressed || key.leftPressed || key.rightPressed || moving) && doublePressed == false ) {
				switch(direction) {
				case "up":
					screenY -= speed;
					break;
				case "down":
					screenY += speed;
					break;
				case "left":
					screenX -= speed;
					break;
				case "right":
					screenX += speed;
					break;
				}
			}
		locationHitBox[0] = screenX + 24 ;
		locationHitBox[1] = screenY + 80;
		hitBox = new Rectangle(locationHitBox[0], locationHitBox[1], 16, 16);
	}
	

	public void draw(Graphics2D g2) {
			updateAnimation();
			update();
			
		g2.setColor(Color.red);
		String leftHand = "" ;
		String rightHand  = "";
		if (getFoodItem[0]!= null) {
			leftHand = getFoodItem[0].getFoodName();
		}
		if (getFoodItem[1] != null) {
			rightHand = getFoodItem[1].getFoodName();
		}
		g2.setFont(new Font("Arial", Font.PLAIN, 12));
		g2.setColor(Color.BLACK);
			switch(direction) {
			case "up" :
				g2.drawImage(animationIdle[8], screenX, screenY,WaiterWidth, WaiterHeight, null);
				break;
			case "down" :
				g2.drawImage(animationIdle[3 + animationIndex], screenX, screenY,WaiterWidth, WaiterHeight, null);
				break;
			case "right" :
				g2.drawImage(animationIdle[6], screenX, screenY,WaiterWidth, WaiterHeight, null);
				break;
			case "left" :
				g2.drawImage(animationIdle[7], screenX, screenY,WaiterWidth, WaiterHeight, null);
				break;
				
		}
			
	}
	private int getAmount(String action) {
		return 3;
	}
	private BufferedImage[] loadAnimation(String name) {
		// TODO Auto-generated method stub
			BufferedImage img = GetSpriteAlats(name);
			int col = img.getWidth() / 64;
			int row = img.getHeight() / 64;
			BufferedImage[] animation = new BufferedImage[col * row];
			int i = 0;
			int j = 0;
				for( j = 0; j < row; j++) {
					for (i = 0; i < col; i++) {
						animation[j * col + i] = img.getSubimage(i * 64, j *96, 64, 96);
					}
			}
			return animation;
	}
	private void updateAnimation() {
		animationTick++;
		if (animationTick >= animationSpeed) {
			animationTick = 0;
			animationIndex++;
			if (animationIndex >= getAmount(WaiterAction) ) {
				animationIndex = 0;
			}
		}
		
	}

	public boolean searchPath(int objIndex) {
		goalReach = false;
		if (onYourWay == 0) {
			
			int startCol = locationHitBox[0] / gp.tileSizeWidth;
			int startRow = locationHitBox[1] / gp.tileSizeHeight;
			int goalCol = gp.obj.get(objIndex).placeCome.x/ gp.tileSizeWidth;
			int goalRow = gp.obj.get(objIndex).placeCome.y/gp.tileSizeHeight;
			moving = true;

			Rectangle k = gp.obj.get(objIndex).placeCome;
			
			gp.pathFinding.setNodes(startCol, startRow, goalCol, goalRow);
			if (gp.pathFinding.search() == true) {
				int nextX = gp.pathFinding.pathList.getLast().col * gp.tileSizeWidth;
				int nextY = gp.pathFinding.pathList.getLast().row * gp.tileSizeHeight;
				int enLeftX = locationHitBox[0];
				int enRightX = enLeftX + locationHitBox[2];
				int enTopY = locationHitBox[1];
				int enBottomY = enTopY + locationHitBox[3];
				int nextCol = gp.pathFinding.pathList.getLast().col;
				int nextRow = gp.pathFinding.pathList.getLast().row;
				if(k.contains(hitBox) || k.intersects(hitBox)) {
					onPath = false;
					moving = false;
					direction = "down";
					gp.mouse.clickObj = false;
					goalReach = true;
					onYourWay = 1;
				}else {
					moving = true;
					goalReach = false;
					gp.mouse.clickObj = false;
					onYourWay = 0;
				}
					
				 if(goalReach == false) {
					 if (enTopY > nextY + speed && enLeftX   > nextX && enRightX < nextX + gp.tileSizeWidth ) {
							direction = "up";
						}else if (enTopY  + speed < nextY && enLeftX  > nextX && enRightX < nextX + gp.tileSizeWidth ) {
							direction = "down";
						}else if (enTopY >= nextY + speed && speed + enBottomY < nextY + gp.tileSizeHeight) {
							if (enLeftX > nextX) {
								direction = "left";
							}
							if (enLeftX < nextX) {
								direction = "right";
							}
						}else if (enTopY > nextY && enLeftX > nextX) {
							direction = "up";
							if (collisionOn == true) {
								direction = "left";
							}
						}else if (enTopY > nextY && enLeftX < nextX) {
							direction = "up";
							if (collisionOn == true) {
								direction = "right";
							}
						}else if (enTopY < nextY && enLeftX > nextX) {
							direction = "down";
							if (collisionOn == true) {
								direction = "left";
							}
						}else if (enTopY < nextY && enLeftX < nextX) {
							direction = "down";
							if (collisionOn == true) {
								direction = "right";
							}
						}
						
				 }
				
				}
		}
		

		return goalReach;
	}
}
