package entity;

import static main.GamePanel.*;

import java.awt.*;


import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;
import java.util.ListIterator;
import java.util.Random;
import javax.imageio.ImageIO;
import main.GamePanel;
import main.FoodItem;

public class Customer extends Entity {
    public static String CustomerAct = "customer4.png";
    public static String outSide = "outside";
    public static String sittingChair = "sittingchair";
    public static String sittingChairDown = "sittingchairdown";
    public static String eat = "eat";
    public static String like = "like";
    public static String angryOrder = "angryorder";
    public static String getMenu = "getmenu";
    public static String order = "order";
    BufferedImage[] animation;
    int animationTick = 0;
    public int animationSpeed = 7;
    int animationIndex = 0;
    public String customerAction;
    public int customerWidth = 80;
    public int customerHeight = gp.tileSizeHeight * 3;
    public int actionindex;
    int count = 0;
    public volatile boolean hasOrder = false;
    public ArrayList<FoodItem> customerOrder;
    public final static int CUSTOMER_MAX = 3;
    public float bill = 0;
    public int done = 0;
    public int waitCounter = 0;
    private int index = -1;
    public boolean orderChanged = false;
    public volatile boolean orderInProcess = false; 
    public boolean isDraw = true;
    public int sizeWave;
    public int checkSpawSizeWave = 0;
    public int maxY =  gp.tileSizeHeight * 14;
    public int xPos , yPos;
    public boolean doneChange = false;
    public Customer(GamePanel gp) {
        super(gp);
        index++;
        onPath = false;
        animation = loadAnimation(CustomerAct);
        customerOrder = new ArrayList<>();
        setDefaultValues();
        xPos = 0;
        yPos = 0;
    }

    public void setDefaultValues() {
        name = "Customer" + gp.customers.size();
        direction = "";
        speed = 32;
    }

    public BufferedImage GetSpriteAlats(String fileName) {
        BufferedImage img = null;
        try {
            img = ImageIO.read(getClass().getResourceAsStream("/customer/" + fileName));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return img;
    }

    public void setAction() {
    	Random rd = new Random();
    	if(checkSpawSizeWave == 0) {
    		sizeWave = rd.nextInt(4);
    		this.checkSpawSizeWave = 1;
    	}
    }

    public void update() {
        collisionOn = false;
    }

    public void draw(Graphics2D g2) {
            updateAnimation();
            setAction();
        if (!leave()) {
        	getPos();
            if (customerAction == outSide) {
                g2.drawImage(animation[0], screenX, screenY, 80, 96, null);
                if (screenY <= maxY) {
                    screenY += 32;
                }
            } else if (customerAction == sittingChair) {
                g2.drawImage(animation[1], xPos + 16, yPos - gp.tileSizeHeight, customerWidth, customerHeight, null);
            }else if (customerAction == sittingChairDown) {
                g2.drawImage(animation[2], xPos + 16, yPos - gp.tileSizeHeight, customerWidth, customerHeight, null);
            }else if (customerAction == getMenu) {
                g2.drawImage(animation[3], xPos + 16, yPos - gp.tileSizeHeight, customerWidth, customerHeight, null);
            } else if (customerAction == order) {
                g2.drawImage(animation[4 +animationIndex], xPos + 16, yPos - gp.tileSizeHeight, customerWidth, customerHeight, null);
            }else if (customerAction == eat) {
                g2.drawImage(animation[7 + animationIndex], xPos + 16, yPos - gp.tileSizeHeight, customerWidth, customerHeight, null);
            }else if (customerAction == like) {
                g2.drawImage(animation[9 + animationIndex], xPos + 16, yPos - gp.tileSizeHeight, customerWidth, customerHeight, null);
            }else if (customerAction == angryOrder) {
                g2.drawImage(animation[12 + animationIndex], xPos + 16, yPos - gp.tileSizeHeight, customerWidth, customerHeight, null);
            }
        }
        }

    private int getAmount(String action) {
        if(action == outSide ||action == getMenu|| action == sittingChair || action == sittingChairDown) {
        	return 1;
        }else if(action == order || action == like) {
        	return 3;
        }else if(action == eat || action == angryOrder) {
        	return 2;
        }
        return 0;
    }

    private BufferedImage[] loadAnimation(String name) {
        BufferedImage img = GetSpriteAlats(name);
        int col = img.getWidth() / 80;
        System.out.println(col);
        BufferedImage[] animation = new BufferedImage[col];
        for (int i = 0; i < col; i++) {
                animation[i] = img.getSubimage(i * 80, 0, 80, 96);
        }
        return animation;
    }

    private void updateAnimation() {
        animationTick++;
        if (animationTick >= animationSpeed) {
            animationTick = 0;
            animationIndex++;
            if (animationIndex >= getAmount(customerAction)) {
                animationIndex = 0;
            }
        }
    }

    public boolean placeOrders() {
        Menu menu = new Menu();
        Random ran = new Random();
        bill = 0;

        ArrayList<String> categoryOrder = new ArrayList<>();
        categoryOrder.add("appetizers");
        categoryOrder.add("mainCourses");
        categoryOrder.add("desserts");
        categoryOrder.add("drinks");

        for (String category : categoryOrder) {
            ArrayList<FoodItem> chosenMenu = null;
            switch (category) {
                case "appetizers":
                    chosenMenu = menu.getAppetizers();
                    break;
                case "mainCourses":
                    chosenMenu = menu.getMainCourses();
                    break;
                case "desserts":
                    chosenMenu = menu.getDesserts();
                    break;
                case "drinks":
                    chosenMenu = menu.getDrinks();
                    break;
            }

            int index = ran.nextInt(chosenMenu.size());
            customerOrder.add(chosenMenu.get(index));
            orderChanged = true;
        }
        return true;
    }

    public void eat(int i) {
        done++;
        System.out.println(name + " is eating " + i);
    }

    public boolean leave() {
        if (done == 4) {
            isDraw = false;
            customerAction = outSide;
            gp.mouse.clickCus = false;
            done = 0;
            hasOrder = false;
            orderInProcess =false;
            screenX = 0;
            screenY = 0;
            customerWidth = 0;
            customerHeight = 0;
            gp.income += gp.chefs.get(0).getMoney;
            if(gp.nhacTinhTien == 0) {
            	gp.playSE(6);
            	gp.nhacTinhTien = 1;
            }
            System.out.println("leaving");
            gp.nhacTinhTien = 0;
            return true;
        }
        return false;
    }

    public void getPos() {
    	if(gp.mouse.previousObjIndex != 9999 && gp.obj.get(gp.mouse.previousObjIndex).name == "table4person" && this == gp.obj.get(gp.mouse.previousObjIndex).service && this.doneChange == false) {
    		this.xPos = gp.obj.get(gp.mouse.previousObjIndex).screenX;
    		this.yPos = gp.obj.get(gp.mouse.previousObjIndex).screenY;
    		doneChange = true;
    	}
    }
}
