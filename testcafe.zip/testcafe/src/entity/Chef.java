package entity;

import java.awt.*;
import main.FoodItem;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;
import main.GamePanel;
import javax.imageio.ImageIO;

public class Chef extends Entity implements Runnable {
    public CopyOnWriteArrayList<FoodItem> dishesProgressbyChef;
    public ArrayList<FoodItem> dishCompleted = new ArrayList<>();
    public static String chefIdle = "chefidle.png";
    public static String chefCook = "chefcook.png";
    BufferedImage[] animationIdle, animationCooking;
    int animationTick = 0;
    int animationSpeed = 30;
    int animationIndex = 0;
    public String chefAction;
    public int chefWidth = gp.tileSizeWidth * 2;
    public int chefHeight = gp.tileSizeHeight * 3;
    public boolean isRunning = false;
    Thread chefThread;
    private boolean keepRunning = true;
    private boolean isPaused = false; 
    public int add = 0;
    private boolean orderChanged = false;
    public float getMoney = 0;
    public int nhacXong1Mon = 0;

    public Chef(GamePanel gp) {
        super(gp);
        this.dishesProgressbyChef = new CopyOnWriteArrayList<>();
        setDefaultValues();
        animationIdle = loadAnimation(chefIdle);
        animationCooking = loadAnimation(chefCook);
    }

    public void receiveOrder() {
        try {
            ArrayList<FoodItem> toRemove = new ArrayList<>();

            for (FoodItem currfi : dishesProgressbyChef) {
                isRunning = true;
                System.out.println(name + " received an order for " + currfi.getFoodName());
                while (!currfi.isCompleted(currfi)) {
                    synchronized (this) {
                        while (isPaused) {
                            wait();
                        }
                    }
                }

                dishCompleted.add(currfi);
                if (nhacXong1Mon == 0) {
                    gp.playSE(5);
                    nhacXong1Mon = 1;
                }

                toRemove.add(currfi);
                orderChanged = true;
                nhacXong1Mon = 0;
                dishesProgressbyChef.removeAll(toRemove);
            }

            dishesProgressbyChef.removeAll(toRemove);
            isRunning = false;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void startChefThread() {
        try {
            System.out.println(dishesProgressbyChef);
            chefThread = new Thread(this);
            chefThread.start();
            isRunning = true;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void run() {
        try {
            while (true && !isPaused) {
                synchronized (this) {
                    while (isPaused) {
                        wait();
                    }
                }
                update();
                receiveOrder();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void setDefaultValues() {
        name = "Chef";
        chefAction = chefIdle;
        direction = "";
    }

    public BufferedImage GetSpriteAlats(String fileName) {
        BufferedImage img = null;
        try {
            img = ImageIO.read(getClass().getResourceAsStream("/npc/" + fileName));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return img;
    }

    public void setAction() {
        try {
            chefAction = chefIdle;
            for (Customer customer : gp.customers) {
                if (customer.hasOrder && !customer.orderInProcess && gp.mouse.previousObjIndex != 9999) {
                    Rectangle rec = gp.obj.get(gp.mouse.previousObjIndex).placeCome;
                    if ((gp.obj.get(gp.mouse.previousObjIndex).name == "cheftable1")&& (rec.intersects(gp.waiters.hitBox) || rec.contains(gp.waiters.hitBox))) {
                        dishesProgressbyChef.addAll(customer.customerOrder);
                        customer.orderInProcess = true;
                        System.out.println("Customer order " + customer.name + " is in process");
                        System.out.println("Order added to chef");
                    }
                }
            }

            if ((gp.mouse.previousObjIndex == 2 && gp.waiters.goalReach && dishesProgressbyChef.size() != 0) || isRunning) {
                chefAction = chefCook;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void update() {
        collisionOn = false;
        setAction();
        if(gp.gameState == gp.pauseState) {
        	for(Chef chef : gp.chefs) {
        		if(chef.chefThread != null) {
        			chef.pause();
        		}
        	}
        }else if (gp.gameState != gp.pauseState) {
        	for(Chef chef : gp.chefs) {
        		if(chef.chefThread != null) {
        			chef.resume();
        		}
        	}
        }
    }

    public void draw(Graphics2D g2) {
        updateAnimation();
        update();

        if (orderChanged || !dishesProgressbyChef.isEmpty()) {
            int maxItemsToShow = 10;
            int yPosition = gp.tileSizeHeight * 3;
            for (int i = 0; i < Math.min(maxItemsToShow, dishesProgressbyChef.size()); i++) {
                orderChanged = false;
            }
        }
       if(chefAction == chefIdle) {
    	   g2.drawImage(animationIdle[0], screenX, screenY, chefWidth, chefHeight, null);
       }else if(chefAction == chefCook) {
    	   g2.drawImage(animationCooking[animationIndex], screenX, screenY, chefWidth, chefHeight, null);
       }
        
    }

    private int getAmount(String action) {
        if(action == chefCook) {
        	return 3;
        }
    	return 1;
    }

    public BufferedImage[] loadAnimation(String name) {
        BufferedImage img = GetSpriteAlats(name);
        int col = img.getWidth() / 80;
        int row = img.getHeight() / 96;
        BufferedImage[] animation = new BufferedImage[col * row];
        for (int j = 0; j < row; j++) {
            for (int i = 0; i < col; i++) {
                animation[j * col + i] = img.getSubimage(i * 80, j * 96, 80, 96);
            }
        }
        return animation;
    }

    private void updateAnimation() {
        animationTick++;
        if (animationTick >= animationSpeed) {
            animationTick = 0;
            animationIndex++;
            if (animationIndex >= getAmount(chefAction)) {
                animationIndex = 0;
            }
        }
    }

    public synchronized void pause() {
        isPaused = true;
    }

    public synchronized void resume() {
        isPaused = false;
        notify();
    }
}
