package tile;

import java.awt.Color;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import javax.imageio.ImageIO;

import main.GamePanel;

public class TileManager {
	GamePanel gp;
	public Tile[] tile;
	public int mapTileNum[][];
	public ArrayList<String> fileNames = new ArrayList<String>();
	public ArrayList<String> collisonStatus = new ArrayList<String>();
	private boolean drawPath = true;
	public TileManager(GamePanel gp) {
		this.gp = gp;
//		tile = new Tile[10];

//		getTileImage();

		InputStream is = getClass().getResourceAsStream("/maps/coo.txt");
		BufferedReader br = new BufferedReader(new InputStreamReader(is));
		String line;
		try {
			while((line = br.readLine()) != null) {
				fileNames.add(line);
				collisonStatus.add(br.readLine());
			}
			br.close();
			System.out.println("load");
		}catch (IOException e) {
			e.getStackTrace();
		}
		tile = new Tile[fileNames.size()];
		getTileImage();
		
		is = getClass().getResourceAsStream("/maps/map.txt");
		br = new BufferedReader(new InputStreamReader(is));
		try {
			String line2 = br.readLine();
			String maxTile[] = line2.split(" ");
//			gp.colInDisplays = maxTile.length;
//			gp.rowInDisplays = maxTile.length;
			gp.colInDisplays = 30;
			gp.rowInDisplays = 20;
			mapTileNum = new int[gp.colInDisplays][gp.rowInDisplays];
			br.close();
		} catch (Exception e) {
			// TODO: handle exception
		}
//		loadMap("map.txt");
	}
	private void getTileImage() {
		for (int i = 0; i < fileNames.size(); i++) {
			String fileName;
			boolean collision = false;
			fileName = fileNames.get(i);
			if (collisonStatus.get(i).equals("true")) {
				collision = true;
			}
			setUp(i, fileName, collision);
		}
	}
	public void setUp(int index, String imageName, boolean collision) {
		try {
			InputStream is = getClass().getResourceAsStream("/Tiles/" + imageName);
			tile[index] = new Tile();
			tile[index].img = ImageIO.read(is);
			tile[index].collision = collision;
		} catch (Exception e) {
			// TODO: handle exception
		}
		System.out.println(index);
		
	}
	public void loadMap(String name){
		
		try {
			InputStream is = getClass().getResourceAsStream("/maps/" + name);
			BufferedReader br = new BufferedReader(new InputStreamReader(is));
			
			int col = 0;
			int row = 0;
			while(col < gp.colInDisplays && row < gp.rowInDisplays) {
				String line = br.readLine();
				while(col < gp.colInDisplays) {
					String numbers[] = line.split(" ");
					int num = Integer.parseInt(numbers[col]);
					mapTileNum[col][row] = num;
					col++;
				}
				if (col == gp.colInDisplays) {
					col = 0;
					row++;
				}
			}
			br.close();
		}catch(IOException e) {
			e.getStackTrace();
		}
	}
	public void draw(Graphics2D g2) {
		int worldCol = 0;
		int worldRow = 0;
		int x = 0, y = 0;
		while(worldCol < gp.colInDisplays && worldRow < gp.rowInDisplays) {
			int tileNum = mapTileNum[worldCol][worldRow];
			g2.drawImage(tile[tileNum].img, x, y,gp.tileSizeWidth, gp.tileSizeHeight, null);
			worldCol++;
			x+= gp.tileSizeWidth;
			if (worldCol == gp.colInDisplays) {
				worldCol = 0;
				worldRow++;
				x = 0;
				y += gp.tileSizeHeight;
			}
		}
	}
}
