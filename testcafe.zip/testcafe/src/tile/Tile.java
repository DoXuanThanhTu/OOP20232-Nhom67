package tile;

import java.awt.image.BufferedImage;

public class Tile {
	public BufferedImage img;
	public boolean collision = false;
	
}
