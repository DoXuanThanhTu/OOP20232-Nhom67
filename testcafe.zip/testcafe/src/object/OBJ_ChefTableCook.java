package object;

import java.awt.Rectangle;
import java.io.IOException;
import java.io.InputStream;

import javax.imageio.ImageIO;

import entity.Entity;
import main.GamePanel;

public class OBJ_ChefTableCook extends Entity{
	public OBJ_ChefTableCook(String objName, GamePanel gp) {
		// TODO Auto-generated constructor stub
		super(gp);
		name = objName;
		type = 0;
		collison = true;
		hitBox[0] = 0;
		hitBox[1] = 0;
		hitBox[2] = gp.tileSizeWidth * 5;
//		hitBox[3] = 224;
		hitBox[3] = gp.tileSizeHeight * 6;
		try {
			InputStream is = getClass().getResourceAsStream("/object/" + name +".png");
			image = ImageIO.read(is);
			widthObject = 160;
			heightObject = 224;
		}catch(IOException e) {
			e.getStackTrace();
		}
		
	}

	@Override
	public void update() {
		// TODO Auto-generated method stub
		
	}
	public void clikOnEntity() {
		// TODO Auto-generated method stub
		
	}
}


