package object;

import java.awt.Rectangle;
import java.io.IOException;
import java.io.InputStream;

import javax.imageio.ImageIO;

import entity.Entity;
import main.GamePanel;

public class OBJ_SodaMachine extends Entity {
	public OBJ_SodaMachine(String objName, GamePanel gp) {
		super(gp);
		name = objName;
		type = 0;
		collison = true;
		hitBox[0] = 0;
		hitBox[1] = gp.tileSizeHeight * 2;
		hitBox[2] = gp.tileSizeWidth * 2;
		hitBox[3] = gp.tileSizeHeight * 2;
		try {
			InputStream is = getClass().getResourceAsStream("/object/" + name +".png");
			image = ImageIO.read(is);
			widthObject = 64;
			heightObject = 128;
		}catch(IOException e) {
			e.getStackTrace();
		}
		placeCome = new Rectangle(screenX - 1, screenY + hitBox[3], gp.tileSizeWidth + 1, gp.tileSizeHeight + 1);
		}


	

	@Override
	public void update() {
		// TODO Auto-generated method stub
		
	}
	public void clikOnEntity() {
		// TODO Auto-generated method stub
		
	}
}
