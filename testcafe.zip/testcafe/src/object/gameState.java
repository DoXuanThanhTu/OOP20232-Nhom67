package object;

import java.awt.Graphics2D;

import java.awt.image.BufferedImage;
import java.io.InputStream;
import java.util.ArrayList;

import javax.imageio.ImageIO;

import main.GamePanel;

public class gameState {
	public ArrayList<BufferedImage> stageImg;
	public GamePanel gp;
	public ArrayList<String> mapsDir = new ArrayList<String>();
	public gameState(GamePanel gp) {
		this.gp = gp;
		//menustartmap
		mapsDir.add("/maps/backgroundmenu.png");
		//playmap
		mapsDir.add("/maps/backgroundfull.png");
		//menu
		mapsDir.add("/maps/pausescreen.png");
		
		//victory
		mapsDir.add("/maps/victory.png");
		stageImg = new ArrayList<BufferedImage>();
		tutorialState();
		gameState();
		loadImgEveryState();
	}
	private void loadImgEveryState() {
		try {
			for (int i = 0; i < mapsDir.size(); i++) {
				InputStream is = getClass().getResourceAsStream(mapsDir.get(i));
				BufferedImage img = ImageIO.read(is);
				stageImg.add(img);
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	private void gameState() {
		// TODO Auto-generated method stub
		
	}
	private void tutorialState() {
		// TODO Auto-generated method stub
		
	}
	
}
