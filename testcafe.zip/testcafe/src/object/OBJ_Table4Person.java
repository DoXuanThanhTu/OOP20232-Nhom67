package object;

import java.awt.Rectangle;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

import javax.imageio.ImageIO;

import entity.Customer;
import entity.Entity;
import main.GamePanel;

public class OBJ_Table4Person extends Entity{
//		public seat 
		public OBJ_Table4Person(String objName, GamePanel gp) {
			// TODO Auto-generated constructor stub
			super(gp);
			name = objName;
			type = 0;
			collison = true;
			hitBox[0] = 0;
			hitBox[1] = 0;
			hitBox[2] = gp.tileSizeWidth * 5 ;
			hitBox[3] = gp.tileSizeHeight * 6;
			try {
				InputStream is = getClass().getResourceAsStream("/object/" + name +".png");
				image = ImageIO.read(is);
				widthObject = 160;
				heightObject = 224;
			}catch(IOException e) {
				e.getStackTrace();
			}
			
		}

		@Override
		public void update() {
			// TODO Auto-generated method stub
			
		}
		public void clikOnEntity() {
			// TODO Auto-generated method stub
			
		}

		public boolean hasCustomer() {
			for(int i = 0; i < chair.length; i++) {
				if(chair[i] == true) return true;
			}
			return false;
		}
		public void inATable(Entity en) {
			if(hasCustomer() == false);
		}

}
